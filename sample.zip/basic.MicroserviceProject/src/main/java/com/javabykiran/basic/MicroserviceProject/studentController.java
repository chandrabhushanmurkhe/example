package com.javabykiran.basic.MicroserviceProject;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class studentController {
	@RequestMapping("firstservice")
	public String welcomemessage() {
		return "we started spring boot at javabykiran";
		
	}

}
