package com.javabykiran.basic.MicroserviceProject;

public interface BasicMicroserviceProjectApplication {

}
